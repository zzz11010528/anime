<template>
  <div class="app-container">
    <router-view />
  </div>
</template>

<style lang="scss">
.app-container {
  height: 100vh;
  width: 100vw;
}
</style>
