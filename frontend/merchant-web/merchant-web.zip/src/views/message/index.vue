<template>
  <div class="message-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <h2>私信管理</h2>
        </div>
      </template>

      <div class="message-layout">
        <!-- 联系人列表 -->
        <div class="contact-list">
          <div class="search-box">
            <el-input
              v-model="searchKeyword"
              placeholder="搜索联系人"
              prefix-icon="Search"
              clearable
              @input="searchContacts"
            />
          </div>

          <div class="contact-items">
            <div
              v-for="contact in filteredContacts"
              :key="contact.userId"
              class="contact-item"
              :class="{ active: currentContact && currentContact.userId === contact.userId }"
              @click="selectContact(contact)"
            >
              <el-avatar :src="contact.avatar" :size="40" />
              <div class="contact-info">
                <div class="contact-name">
                  {{ contact.nickname }}
                  <el-badge v-if="contact.unreadCount > 0" :value="contact.unreadCount" class="unread-badge" />
                </div>
                <div class="contact-preview">{{ contact.lastMessage }}</div>
              </div>
              <div class="contact-time">{{ formatTime(contact.lastTime) }}</div>
            </div>
          </div>
        </div>

        <!-- 聊天区域 -->
        <div class="chat-area">
          <template v-if="currentContact">
            <div class="chat-header">
              <div class="chat-title">{{ currentContact.nickname }}</div>
              <div class="chat-actions">
                <el-button type="primary" size="small" @click="handleViewUser">查看用户</el-button>
              </div>
            </div>

            <div class="chat-messages" ref="messagesContainer">
              <div v-if="loading" class="loading-container">
                <el-spinner />
              </div>

              <template v-else>
                <div v-if="messages.length === 0" class="empty-messages">
                  <el-empty description="暂无消息记录" />
                </div>

                <template v-else>
                  <div
                    v-for="(message, index) in messages"
                    :key="index"
                    class="message-item"
                    :class="{ 'message-self': message.isSelf }"
                  >
                    <div class="message-avatar">
                      <el-avatar
                        :src="message.isSelf ? merchantInfo.avatar : currentContact.avatar"
                        :size="36"
                      />
                    </div>
                    <div class="message-content">
                      <div class="message-bubble">
                        <div v-if="message.type === 'text'" class="message-text">
                          {{ message.content }}
                        </div>
                        <div v-else-if="message.type === 'image'" class="message-image">
                          <el-image
                            :src="message.content"
                            :preview-src-list="[message.content]"
                            fit="cover"
                          />
                        </div>
                        <div v-else-if="message.type === 'product'" class="message-product">
                          <div class="product-card">
                            <el-image :src="message.product.image" class="product-image" />
                            <div class="product-info">
                              <div class="product-name">{{ message.product.name }}</div>
                              <div class="product-price">¥{{ message.product.price }}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="message-time">{{ formatTime(message.time) }}</div>
                    </div>
                  </div>
                </template>
              </template>
            </div>

            <div class="chat-input">
              <div class="input-toolbar">
                <el-tooltip content="发送图片" placement="top">
                  <el-button type="primary" text circle @click="handleUploadImage">
                    <el-icon><Picture /></el-icon>
                  </el-button>
                </el-tooltip>
                <el-tooltip content="发送商品" placement="top">
                  <el-button type="primary" text circle @click="handleSendProduct">
                    <el-icon><Goods /></el-icon>
                  </el-button>
                </el-tooltip>
                <input
                  ref="imageInput"
                  type="file"
                  accept="image/*"
                  style="display: none"
                  @change="handleImageSelected"
                />
              </div>
              <div class="input-area">
                <el-input
                  v-model="messageInput"
                  type="textarea"
                  :rows="3"
                  placeholder="请输入消息内容..."
                  resize="none"
                  @keydown.enter.prevent="sendMessage"
                />
                <el-button type="primary" @click="sendMessage" :disabled="!messageInput.trim()">
                  发送
                </el-button>
              </div>
            </div>
          </template>

          <div v-else class="empty-chat">
            <el-empty description="请选择联系人开始聊天" />
          </div>
        </div>
      </div>
    </el-card>

    <!-- 选择商品对话框 -->
    <el-dialog v-model="productDialogVisible" title="选择商品" width="600px">
      <div class="product-search">
        <el-input
          v-model="productKeyword"
          placeholder="搜索商品"
          prefix-icon="Search"
          clearable
          @input="searchProducts"
        />
      </div>

      <el-table
        v-loading="productLoading"
        :data="productList"
        border
        style="width: 100%"
        @row-click="handleSelectProduct"
      >
        <el-table-column label="商品图片" width="80">
          <template #default="scope">
            <el-image
              :src="scope.row.mainImage"
              :preview-src-list="[scope.row.mainImage]"
              fit="cover"
              style="width: 50px; height: 50px"
            />
          </template>
        </el-table-column>
        <el-table-column prop="name" label="商品名称" min-width="200" show-overflow-tooltip />
        <el-table-column label="价格" width="100">
          <template #default="scope">
            ¥{{ scope.row.price }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100">
          <template #default="scope">
            <el-button type="primary" size="small" @click.stop="sendProductMessage(scope.row)">
              发送
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="productPage"
          v-model:page-size="productPageSize"
          :page-sizes="[5, 10, 20]"
          layout="total, sizes, prev, pager, next"
          :total="productTotal"
          @size-change="handleProductSizeChange"
          @current-change="handleProductCurrentChange"
        />
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Picture, Goods } from '@element-plus/icons-vue'
import { useMerchantStore } from '../../stores/merchant'
import { getProductList } from '../../api/product'

const router = useRouter()
const merchantStore = useMerchantStore()

// 状态
const loading = ref(false)
const searchKeyword = ref('')
const messageInput = ref('')
const currentContact = ref(null)
const messages = ref([])
const messagesContainer = ref(null)
const imageInput = ref(null)
const productDialogVisible = ref(false)
const productLoading = ref(false)
const productKeyword = ref('')
const productList = ref([])
const productPage = ref(1)
const productPageSize = ref(10)
const productTotal = ref(0)

// 计算属性
const merchantInfo = computed(() => merchantStore.merchantInfo)
const filteredContacts = computed(() => {
  if (!searchKeyword.value) return contacts.value
  
  return contacts.value.filter(contact => 
    contact.nickname.toLowerCase().includes(searchKeyword.value.toLowerCase())
  )
})

// 模拟数据
const contacts = ref([
  {
    userId: 1,
    nickname: '张三',
    avatar: 'https://via.placeholder.com/100',
    lastMessage: '您好，请问这个商品有货吗？',
    lastTime: '2023-05-20 10:30:00',
    unreadCount: 2
  },
  {
    userId: 2,
    nickname: '李四',
    avatar: 'https://via.placeholder.com/100',
    lastMessage: '好的，谢谢！',
    lastTime: '2023-05-19 15:45:00',
    unreadCount: 0
  },
  {
    userId: 3,
    nickname: '王五',
    avatar: 'https://via.placeholder.com/100',
    lastMessage: '请问什么时候发货？',
    lastTime: '2023-05-18 09:20:00',
    unreadCount: 1
  }
])

// 初始化
onMounted(() => {
  // 如果有联系人，默认选择第一个
  if (contacts.value.length > 0) {
    selectContact(contacts.value[0])
  }
})

// 搜索联系人
function searchContacts() {
  // 实际项目中应该调用API进行搜索
}

// 选择联系人
function selectContact(contact) {
  currentContact.value = contact
  loading.value = true
  
  // 模拟加载消息
  setTimeout(() => {
    // 模拟消息数据
    messages.value = [
      {
        id: 1,
        content: '您好，请问这个商品有货吗？',
        type: 'text',
        time: '2023-05-20 10:30:00',
        isSelf: false
      },
      {
        id: 2,
        content: '您好，目前有货，可以下单。',
        type: 'text',
        time: '2023-05-20 10:32:00',
        isSelf: true
      },
      {
        id: 3,
        content: '好的，我想了解一下这个商品的详情',
        type: 'text',
        time: '2023-05-20 10:33:00',
        isSelf: false
      },
      {
        id: 4,
        content: 'https://via.placeholder.com/300',
        type: 'image',
        time: '2023-05-20 10:35:00',
        isSelf: true
      },
      {
        id: 5,
        product: {
          id: 1,
          name: '测试商品',
          price: '99.00',
          image: 'https://via.placeholder.com/100'
        },
        type: 'product',
        time: '2023-05-20 10:36:00',
        isSelf: true
      }
    ]
    
    loading.value = false
    
    // 标记消息为已读
    if (contact.unreadCount > 0) {
      contact.unreadCount = 0
    }
    
    // 滚动到底部
    scrollToBottom()
  }, 500)
}

// 发送消息
function sendMessage() {
  if (!messageInput.value.trim()) return
  
  // 添加消息到列表
  messages.value.push({
    id: Date.now(),
    content: messageInput.value,
    type: 'text',
    time: new Date().toISOString().replace('T', ' ').substring(0, 19),
    isSelf: true
  })
  
  // 清空输入框
  messageInput.value = ''
  
  // 滚动到底部
  scrollToBottom()
  
  // 模拟对方回复
  setTimeout(() => {
    messages.value.push({
      id: Date.now() + 1,
      content: '好的，我知道了',
      type: 'text',
      time: new Date().toISOString().replace('T', ' ').substring(0, 19),
      isSelf: false
    })
    
    // 滚动到底部
    scrollToBottom()
  }, 1000)
}

// 滚动到底部
function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// 格式化时间
function formatTime(timeStr) {
  if (!timeStr) return ''
  
  const date = new Date(timeStr)
  const now = new Date()
  
  // 如果是今天
  if (date.toDateString() === now.toDateString()) {
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  }
  
  // 如果是昨天
  const yesterday = new Date(now)
  yesterday.setDate(now.getDate() - 1)
  if (date.toDateString() === yesterday.toDateString()) {
    return `昨天 ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  }
  
  // 如果是今年
  if (date.getFullYear() === now.getFullYear()) {
    return `${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  }
  
  // 其他情况
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

// 查看用户
function handleViewUser() {
  ElMessage.info(`查看用户：${currentContact.value.nickname}`)
  // 实际项目中应该跳转到用户详情页
}

// 上传图片
function handleUploadImage() {
  imageInput.value.click()
}

// 处理图片选择
function handleImageSelected(event) {
  const file = event.target.files[0]
  if (!file) return
  
  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请选择图片文件')
    return
  }
  
  // 检查文件大小（限制为5MB）
  if (file.size > 5 * 1024 * 1024) {
    ElMessage.error('图片大小不能超过5MB')
    return
  }
  
  // 模拟上传图片
  const reader = new FileReader()
  reader.onload = (e) => {
    // 添加图片消息
    messages.value.push({
      id: Date.now(),
      content: e.target.result,
      type: 'image',
      time: new Date().toISOString().replace('T', ' ').substring(0, 19),
      isSelf: true
    })
    
    // 滚动到底部
    scrollToBottom()
  }
  reader.readAsDataURL(file)
  
  // 清空文件输入框，以便再次选择同一文件
  event.target.value = ''
}

// 发送商品
function handleSendProduct() {
  productDialogVisible.value = true
  searchProducts()
}

// 搜索商品
async function searchProducts() {
  productLoading.value = true
  
  try {
    const res = await getProductList({
      keyword: productKeyword.value,
      page: productPage.value,
      size: productPageSize.value,
      status: 1 // 只查询上架商品
    })
    
    productList.value = res.data.records
    productTotal.value = res.data.total
  } catch (error) {
    console.error('搜索商品失败:', error)
    ElMessage.error('搜索商品失败')
  } finally {
    productLoading.value = false
  }
}

// 处理商品分页大小变化
function handleProductSizeChange(val) {
  productPageSize.value = val
  searchProducts()
}

// 处理商品页码变化
function handleProductCurrentChange(val) {
  productPage.value = val
  searchProducts()
}

// 选择商品
function handleSelectProduct(row) {
  sendProductMessage(row)
}

// 发送商品消息
function sendProductMessage(product) {
  // 添加商品消息
  messages.value.push({
    id: Date.now(),
    product: {
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.mainImage
    },
    type: 'product',
    time: new Date().toISOString().replace('T', ' ').substring(0, 19),
    isSelf: true
  })
  
  // 关闭对话框
  productDialogVisible.value = false
  
  // 滚动到底部
  scrollToBottom()
}
</script>

<style lang="scss" scoped>
.message-container {
  .message-layout {
    display: flex;
    height: 600px;
    border: 1px solid #ebeef5;
    border-radius: 4px;
    overflow: hidden;
    
    .contact-list {
      width: 280px;
      border-right: 1px solid #ebeef5;
      display: flex;
      flex-direction: column;
      
      .search-box {
        padding: 10px;
        border-bottom: 1px solid #ebeef5;
      }
      
      .contact-items {
        flex: 1;
        overflow-y: auto;
        
        .contact-item {
          display: flex;
          align-items: center;
          padding: 10px;
          cursor: pointer;
          transition: background-color 0.3s;
          
          &:hover {
            background-color: #f5f7fa;
          }
          
          &.active {
            background-color: #ecf5ff;
          }
          
          .contact-info {
            flex: 1;
            margin-left: 10px;
            overflow: hidden;
            
            .contact-name {
              font-weight: bold;
              margin-bottom: 5px;
              display: flex;
              align-items: center;
              
              .unread-badge {
                margin-left: 5px;
              }
            }
            
            .contact-preview {
              color: #999;
              font-size: 12px;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }
          }
          
          .contact-time {
            font-size: 12px;
            color: #999;
          }
        }
      }
    }
    
    .chat-area {
      flex: 1;
      display: flex;
      flex-direction: column;
      
      .chat-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 15px;
        border-bottom: 1px solid #ebeef5;
        
        .chat-title {
          font-weight: bold;
          font-size: 16px;
        }
      }
      
      .chat-messages {
        flex: 1;
        padding: 15px;
        overflow-y: auto;
        background-color: #f5f7fa;
        
        .loading-container {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100%;
        }
        
        .empty-messages {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100%;
        }
        
        .message-item {
          display: flex;
          margin-bottom: 15px;
          
          &.message-self {
            flex-direction: row-reverse;
            
            .message-content {
              align-items: flex-end;
              margin-right: 10px;
              margin-left: 0;
              
              .message-bubble {
                background-color: #95ec69;
                border-radius: 10px 0 10px 10px;
              }
            }
          }
          
          .message-content {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-left: 10px;
            max-width: 70%;
            
            .message-bubble {
              background-color: #fff;
              padding: 10px;
              border-radius: 0 10px 10px 10px;
              box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
              
              .message-text {
                word-break: break-word;
              }
              
              .message-image {
                max-width: 200px;
                
                .el-image {
                  width: 100%;
                  border-radius: 4px;
                }
              }
              
              .message-product {
                .product-card {
                  display: flex;
                  align-items: center;
                  background-color: #f8f8f8;
                  padding: 10px;
                  border-radius: 4px;
                  
                  .product-image {
                    width: 50px;
                    height: 50px;
                    margin-right: 10px;
                    border-radius: 4px;
                  }
                  
                  .product-info {
                    .product-name {
                      font-weight: bold;
                      margin-bottom: 5px;
                    }
                    
                    .product-price {
                      color: #f56c6c;
                    }
                  }
                }
              }
            }
            
            .message-time {
              font-size: 12px;
              color: #999;
              margin-top: 5px;
            }
          }
        }
      }
      
      .chat-input {
        border-top: 1px solid #ebeef5;
        
        .input-toolbar {
          display: flex;
          padding: 10px;
          border-bottom: 1px solid #f0f0f0;
        }
        
        .input-area {
          display: flex;
          padding: 10px;
          
          .el-textarea {
            flex: 1;
            margin-right: 10px;
          }
        }
      }
      
      .empty-chat {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        background-color: #f5f7fa;
      }
    }
  }
  
  .product-search {
    margin-bottom: 15px;
  }
  
  .pagination-container {
    margin-top: 15px;
    text-align: right;
  }
}
</style>
