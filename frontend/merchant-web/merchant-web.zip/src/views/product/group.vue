<template>
  <div class="group-buying-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <h2>拼团管理</h2>
          <el-button type="primary" @click="handleAddGroup">创建拼团</el-button>
        </div>
      </template>

      <!-- 搜索区域 -->
      <div class="search-container">
        <el-form :inline="true" :model="searchForm" class="search-form">
          <el-form-item label="商品名称">
            <el-input v-model="searchForm.keyword" placeholder="请输入商品名称" clearable />
          </el-form-item>
          <el-form-item label="拼团状态">
            <el-select v-model="searchForm.status" placeholder="请选择状态" clearable>
              <el-option label="未开始" :value="2" />
              <el-option label="进行中" :value="1" />
              <el-option label="已结束" :value="0" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">搜索</el-button>
            <el-button @click="resetSearch">重置</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 表格区域 -->
      <el-table
        v-loading="loading"
        :data="groupList"
        border
        style="width: 100%"
      >
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column label="商品信息" min-width="250">
          <template #default="scope">
            <div class="product-info">
              <el-image
                :src="scope.row.productImage"
                :preview-src-list="[scope.row.productImage]"
                fit="cover"
                class="product-image"
              />
              <div class="product-detail">
                <div class="product-name">{{ scope.row.productName }}</div>
                <div class="product-price">
                  <span class="original-price">原价: ¥{{ scope.row.productPrice }}</span>
                  <span class="group-price">拼团价: ¥{{ scope.row.groupPrice }}</span>
                </div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="拼团规则" width="180">
          <template #default="scope">
            <div>
              <div>{{ scope.row.minGroupSize }}-{{ scope.row.maxGroupSize }}人成团</div>
              <div>已成团: {{ scope.row.groupedCount || 0 }}个</div>
              <div>拼团中: {{ scope.row.groupingCount || 0 }}个</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="活动时间" width="240">
          <template #default="scope">
            <div>
              <div>开始: {{ formatDate(scope.row.startTime) }}</div>
              <div>结束: {{ formatDate(scope.row.endTime) }}</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ getStatusText(scope.row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="scope">
            <el-button
              v-if="scope.row.status === 2"
              type="primary"
              size="small"
              @click="handleEdit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              v-if="scope.row.status !== 0"
              type="danger"
              size="small"
              @click="handleEnd(scope.row)"
            >
              结束
            </el-button>
            <el-button
              type="info"
              size="small"
              @click="handleViewOrders(scope.row)"
            >
              查看订单
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 创建/编辑拼团对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '创建拼团' : '编辑拼团'"
      width="600px"
    >
      <el-form
        ref="groupFormRef"
        :model="groupForm"
        :rules="groupRules"
        label-width="100px"
      >
        <el-form-item label="选择商品" prop="productId">
          <el-select
            v-model="groupForm.productId"
            filterable
            remote
            reserve-keyword
            placeholder="请输入商品名称搜索"
            :remote-method="searchProducts"
            :loading="productLoading"
            @change="handleProductChange"
          >
            <el-option
              v-for="item in productOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
              <div class="product-option">
                <el-image :src="item.mainImage" class="option-image" />
                <span>{{ item.name }}</span>
                <span class="option-price">¥{{ item.price }}</span>
              </div>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="拼团价格" prop="groupPrice">
          <el-input-number
            v-model="groupForm.groupPrice"
            :min="0.01"
            :precision="2"
            :step="0.1"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="成团人数" required>
          <div class="group-size-container">
            <el-form-item prop="minGroupSize" class="group-size-item">
              <el-input-number
                v-model="groupForm.minGroupSize"
                :min="2"
                :max="groupForm.maxGroupSize"
                :step="1"
                controls-position="right"
                placeholder="最小人数"
              />
            </el-form-item>
            <span class="separator">-</span>
            <el-form-item prop="maxGroupSize" class="group-size-item">
              <el-input-number
                v-model="groupForm.maxGroupSize"
                :min="groupForm.minGroupSize"
                :step="1"
                controls-position="right"
                placeholder="最大人数"
              />
            </el-form-item>
          </div>
        </el-form-item>
        <el-form-item label="活动时间" prop="timeRange" required>
          <el-date-picker
            v-model="groupForm.timeRange"
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始时间"
            end-placeholder="结束时间"
            value-format="YYYY-MM-DD HH:mm:ss"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitGroupForm">确定</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 查看订单对话框 -->
    <el-dialog
      v-model="orderDialogVisible"
      title="拼团订单"
      width="800px"
    >
      <el-tabs v-model="orderTabActive">
        <el-tab-pane label="拼团中" name="grouping">
          <el-table :data="groupingOrders" border style="width: 100%">
            <el-table-column prop="id" label="拼团ID" width="80" />
            <el-table-column prop="leaderName" label="团长" width="120" />
            <el-table-column prop="currentSize" label="当前人数" width="100" />
            <el-table-column prop="expireTime" label="过期时间" width="180" />
            <el-table-column label="操作" width="120">
              <template #default="scope">
                <el-button type="primary" size="small" @click="viewGroupDetail(scope.row)">
                  查看详情
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="已成团" name="grouped">
          <el-table :data="groupedOrders" border style="width: 100%">
            <el-table-column prop="id" label="拼团ID" width="80" />
            <el-table-column prop="leaderName" label="团长" width="120" />
            <el-table-column prop="currentSize" label="成团人数" width="100" />
            <el-table-column prop="createdAt" label="创建时间" width="180" />
            <el-table-column prop="updatedAt" label="成团时间" width="180" />
            <el-table-column label="操作" width="120">
              <template #default="scope">
                <el-button type="primary" size="small" @click="viewGroupDetail(scope.row)">
                  查看详情
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getProductList } from '../../api/product'

// 状态
const loading = ref(false)
const groupList = ref([])
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const dialogVisible = ref(false)
const dialogType = ref('add')
const groupFormRef = ref(null)
const productLoading = ref(false)
const productOptions = ref([])
const orderDialogVisible = ref(false)
const orderTabActive = ref('grouping')
const groupingOrders = ref([])
const groupedOrders = ref([])

// 搜索表单
const searchForm = reactive({
  keyword: '',
  status: ''
})

// 拼团表单
const groupForm = reactive({
  id: null,
  productId: null,
  productName: '',
  productPrice: 0,
  groupPrice: 0,
  minGroupSize: 2,
  maxGroupSize: 5,
  timeRange: []
})

// 表单验证规则
const groupRules = {
  productId: [{ required: true, message: '请选择商品', trigger: 'change' }],
  groupPrice: [{ required: true, message: '请输入拼团价格', trigger: 'blur' }],
  minGroupSize: [{ required: true, message: '请输入最小成团人数', trigger: 'blur' }],
  maxGroupSize: [{ required: true, message: '请输入最大成团人数', trigger: 'blur' }],
  timeRange: [{ required: true, message: '请选择活动时间', trigger: 'change' }]
}

// 初始化
onMounted(() => {
  fetchGroupList()
})

// 获取拼团列表
function fetchGroupList() {
  loading.value = true
  // 模拟数据，实际项目中应该调用后端API
  setTimeout(() => {
    groupList.value = [
      {
        id: 1,
        productId: 1,
        productName: '测试商品1',
        productImage: 'https://via.placeholder.com/100',
        productPrice: 100,
        groupPrice: 80,
        minGroupSize: 2,
        maxGroupSize: 5,
        startTime: '2023-05-01 00:00:00',
        endTime: '2023-06-30 23:59:59',
        status: 1,
        groupedCount: 3,
        groupingCount: 2
      },
      {
        id: 2,
        productId: 2,
        productName: '测试商品2',
        productImage: 'https://via.placeholder.com/100',
        productPrice: 200,
        groupPrice: 150,
        minGroupSize: 3,
        maxGroupSize: 10,
        startTime: '2023-06-01 00:00:00',
        endTime: '2023-07-31 23:59:59',
        status: 1,
        groupedCount: 1,
        groupingCount: 4
      }
    ]
    total.value = 2
    loading.value = false
  }, 500)
}

// 搜索商品
async function searchProducts(query) {
  if (query) {
    productLoading.value = true
    try {
      const res = await getProductList({
        keyword: query,
        status: 1,
        page: 1,
        size: 20
      })
      productOptions.value = res.data.records
    } catch (error) {
      console.error('搜索商品失败:', error)
    } finally {
      productLoading.value = false
    }
  } else {
    productOptions.value = []
  }
}

// 处理商品选择变化
function handleProductChange(productId) {
  const product = productOptions.value.find(item => item.id === productId)
  if (product) {
    groupForm.productName = product.name
    groupForm.productPrice = product.price
    // 默认拼团价为原价的8折
    groupForm.groupPrice = Math.floor(product.price * 0.8 * 100) / 100
  }
}

// 格式化日期
function formatDate(dateStr) {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

// 获取状态类型
function getStatusType(status) {
  switch (status) {
    case 0: return 'info'
    case 1: return 'success'
    case 2: return 'warning'
    default: return 'info'
  }
}

// 获取状态文本
function getStatusText(status) {
  switch (status) {
    case 0: return '已结束'
    case 1: return '进行中'
    case 2: return '未开始'
    default: return '未知'
  }
}

// 处理搜索
function handleSearch() {
  currentPage.value = 1
  fetchGroupList()
}

// 重置搜索
function resetSearch() {
  searchForm.keyword = ''
  searchForm.status = ''
  handleSearch()
}

// 处理分页大小变化
function handleSizeChange(val) {
  pageSize.value = val
  fetchGroupList()
}

// 处理页码变化
function handleCurrentChange(val) {
  currentPage.value = val
  fetchGroupList()
}

// 处理添加拼团
function handleAddGroup() {
  dialogType.value = 'add'
  resetGroupForm()
  dialogVisible.value = true
}

// 处理编辑拼团
function handleEdit(row) {
  dialogType.value = 'edit'
  resetGroupForm()
  
  // 填充表单数据
  groupForm.id = row.id
  groupForm.productId = row.productId
  groupForm.productName = row.productName
  groupForm.productPrice = row.productPrice
  groupForm.groupPrice = row.groupPrice
  groupForm.minGroupSize = row.minGroupSize
  groupForm.maxGroupSize = row.maxGroupSize
  groupForm.timeRange = [row.startTime, row.endTime]
  
  dialogVisible.value = true
}

// 重置拼团表单
function resetGroupForm() {
  groupForm.id = null
  groupForm.productId = null
  groupForm.productName = ''
  groupForm.productPrice = 0
  groupForm.groupPrice = 0
  groupForm.minGroupSize = 2
  groupForm.maxGroupSize = 5
  groupForm.timeRange = []
  
  if (groupFormRef.value) {
    groupFormRef.value.resetFields()
  }
}

// 提交拼团表单
function submitGroupForm() {
  groupFormRef.value.validate(valid => {
    if (valid) {
      // 构建提交数据
      const submitData = {
        id: groupForm.id,
        productId: groupForm.productId,
        groupPrice: groupForm.groupPrice,
        minGroupSize: groupForm.minGroupSize,
        maxGroupSize: groupForm.maxGroupSize,
        startTime: groupForm.timeRange[0],
        endTime: groupForm.timeRange[1]
      }
      
      console.log('提交数据:', submitData)
      
      // 模拟提交
      setTimeout(() => {
        ElMessage.success(dialogType.value === 'add' ? '创建成功' : '更新成功')
        dialogVisible.value = false
        fetchGroupList()
      }, 500)
    }
  })
}

// 处理结束拼团
function handleEnd(row) {
  ElMessageBox.confirm('确定要结束该拼团活动吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    // 模拟结束拼团
    setTimeout(() => {
      ElMessage.success('拼团活动已结束')
      fetchGroupList()
    }, 500)
  }).catch(() => {})
}

// 处理查看订单
function handleViewOrders(row) {
  // 模拟获取拼团订单数据
  groupingOrders.value = [
    {
      id: 1,
      groupBuyingId: row.id,
      leaderName: '用户A',
      currentSize: 1,
      expireTime: '2023-06-15 12:00:00',
      status: 0
    }
  ]
  
  groupedOrders.value = [
    {
      id: 2,
      groupBuyingId: row.id,
      leaderName: '用户B',
      currentSize: 3,
      createdAt: '2023-05-10 10:00:00',
      updatedAt: '2023-05-10 15:30:00',
      status: 1
    }
  ]
  
  orderDialogVisible.value = true
}

// 查看拼团详情
function viewGroupDetail(row) {
  console.log('查看拼团详情:', row)
  // 实际项目中应该跳转到拼团详情页或打开详情对话框
}
</script>

<style lang="scss" scoped>
.group-buying-container {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .search-container {
    margin-bottom: 20px;
  }
  
  .product-info {
    display: flex;
    align-items: center;
    
    .product-image {
      width: 60px;
      height: 60px;
      margin-right: 10px;
      border-radius: 4px;
    }
    
    .product-detail {
      .product-name {
        font-weight: bold;
        margin-bottom: 5px;
      }
      
      .product-price {
        .original-price {
          color: #999;
          text-decoration: line-through;
          margin-right: 10px;
        }
        
        .group-price {
          color: #f56c6c;
          font-weight: bold;
        }
      }
    }
  }
  
  .pagination-container {
    margin-top: 20px;
    text-align: right;
  }
  
  .product-option {
    display: flex;
    align-items: center;
    
    .option-image {
      width: 30px;
      height: 30px;
      margin-right: 10px;
    }
    
    .option-price {
      margin-left: auto;
      color: #f56c6c;
    }
  }
  
  .group-size-container {
    display: flex;
    align-items: center;
    
    .group-size-item {
      margin-bottom: 0;
    }
    
    .separator {
      margin: 0 10px;
    }
  }
}
</style>
