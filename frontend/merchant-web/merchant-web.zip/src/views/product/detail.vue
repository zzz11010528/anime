<template>
  <div class="product-detail-container">
    <el-card class="detail-card">
      <template #header>
        <div class="card-header">
          <h2>商品详情</h2>
          <div class="header-actions">
            <el-button @click="goBack">返回</el-button>
            <el-button type="primary" @click="handleEdit">编辑</el-button>
          </div>
        </div>
      </template>
      
      <el-descriptions :column="2" border>
        <el-descriptions-item label="商品ID">{{ product.id }}</el-descriptions-item>
        <el-descriptions-item label="商品状态">
          <el-tag :type="getStatusType(product.status)">{{ getStatusText(product.status) }}</el-tag>
        </el-descriptions-item>
        
        <el-descriptions-item label="商品名称" :span="2">{{ product.name }}</el-descriptions-item>
        
        <el-descriptions-item label="商品分类">{{ product.categoryName }}</el-descriptions-item>
        <el-descriptions-item label="IP">{{ product.ipName }}</el-descriptions-item>
        
        <el-descriptions-item label="商品简介" :span="2">{{ product.brief }}</el-descriptions-item>
        
        <el-descriptions-item label="商品价格">¥{{ formatPrice(product.price) }}</el-descriptions-item>
        <el-descriptions-item label="原价">¥{{ formatPrice(product.originalPrice) }}</el-descriptions-item>
        
        <el-descriptions-item label="库存">{{ product.stock }}</el-descriptions-item>
        <el-descriptions-item label="库存预警值">{{ product.lowStock }}</el-descriptions-item>
        
        <el-descriptions-item label="销量">{{ product.sales }}</el-descriptions-item>
        <el-descriptions-item label="单次限购">{{ product.limitPerOrder || '不限购' }}</el-descriptions-item>
        
        <el-descriptions-item label="商品重量">{{ product.weight }}kg</el-descriptions-item>
        <el-descriptions-item label="商品体积">{{ product.volume }}m³</el-descriptions-item>
        
        <el-descriptions-item label="运费模板">{{ product.freightTemplateName }}</el-descriptions-item>
        <el-descriptions-item label="排序值">{{ product.sort }}</el-descriptions-item>
        
        <el-descriptions-item label="推荐设置">
          <el-tag v-if="product.isNew" type="success" effect="plain" style="margin-right: 5px">新品</el-tag>
          <el-tag v-if="product.isHot" type="danger" effect="plain" style="margin-right: 5px">热门</el-tag>
          <el-tag v-if="product.isRecommend" type="warning" effect="plain">推荐</el-tag>
        </el-descriptions-item>
        
        <el-descriptions-item label="服务保障">
          <el-tag v-if="product.services?.hasQualityAssurance" type="info" effect="plain" style="margin-right: 5px">正品保障</el-tag>
          <el-tag v-if="product.services?.hasSevenDayReturn" type="info" effect="plain" style="margin-right: 5px">7天无理由退货</el-tag>
          <el-tag v-if="product.services?.hasExpressDelivery" type="info" effect="plain" style="margin-right: 5px">急速发货</el-tag>
          <el-tag v-if="product.services?.hasAfterSale" type="info" effect="plain">售后无忧</el-tag>
        </el-descriptions-item>
        
        <el-descriptions-item label="创建时间">{{ formatDateTime(product.createdAt) }}</el-descriptions-item>
        <el-descriptions-item label="更新时间">{{ formatDateTime(product.updatedAt) }}</el-descriptions-item>
      </el-descriptions>
      
      <!-- 商品图片 -->
      <div class="image-section">
        <div class="section-title">商品图片</div>
        
        <div class="main-image">
          <div class="image-title">主图</div>
          <el-image
            :src="product.mainImage"
            :preview-src-list="[product.mainImage]"
            fit="contain"
            style="width: 200px; height: 200px"
          />
        </div>
        
        <div class="image-list">
          <div class="image-title">图片列表</div>
          <div class="images">
            <el-image
              v-for="(image, index) in product.images"
              :key="index"
              :src="image"
              :preview-src-list="product.images"
              fit="contain"
              style="width: 100px; height: 100px; margin-right: 10px; margin-bottom: 10px"
            />
          </div>
        </div>
      </div>
      
      <!-- 规格属性 -->
      <div class="spec-section">
        <div class="section-title">规格属性</div>
        
        <div class="spec-groups" v-if="product.specGroups && product.specGroups.length > 0">
          <div class="spec-title">商品规格</div>
          <el-table :data="product.specGroups" border style="width: 100%">
            <el-table-column prop="name" label="规格名称" width="180" />
            <el-table-column prop="values" label="规格值">
              <template #default="{ row }">
                <el-tag
                  v-for="(value, index) in row.values"
                  :key="index"
                  style="margin-right: 5px; margin-bottom: 5px"
                >
                  {{ value }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
        </div>
        
        <div class="attr-list" v-if="product.attributes && product.attributes.length > 0">
          <div class="attr-title">商品属性</div>
          <el-table :data="product.attributes" border style="width: 100%">
            <el-table-column prop="name" label="属性名称" width="180" />
            <el-table-column prop="value" label="属性值" />
          </el-table>
        </div>
      </div>
      
      <!-- 商品详情 -->
      <div class="detail-section">
        <div class="section-title">商品详情</div>
        
        <div class="detail-content">
          <div class="detail-text">{{ product.detail }}</div>
          
          <div class="detail-images" v-if="product.detailImages && product.detailImages.length > 0">
            <div class="detail-images-title">详情图片</div>
            <div v-for="(image, index) in product.detailImages" :key="index" class="detail-image-item">
              <el-image
                :src="image"
                :preview-src-list="product.detailImages"
                fit="contain"
                style="max-width: 100%"
              />
            </div>
          </div>
        </div>
      </div>
      
      <!-- 销售数据 -->
      <div class="sales-section">
        <div class="section-title">销售数据</div>
        
        <el-row :gutter="20">
          <el-col :span="8">
            <el-card shadow="hover" class="data-card">
              <template #header>
                <div class="data-header">
                  <span>总销量</span>
                </div>
              </template>
              <div class="data-content">
                <div class="data-value">{{ product.sales || 0 }}</div>
                <div class="data-label">件</div>
              </div>
            </el-card>
          </el-col>
          
          <el-col :span="8">
            <el-card shadow="hover" class="data-card">
              <template #header>
                <div class="data-header">
                  <span>总销售额</span>
                </div>
              </template>
              <div class="data-content">
                <div class="data-value">¥{{ formatPrice(product.salesAmount || 0) }}</div>
                <div class="data-label">元</div>
              </div>
            </el-card>
          </el-col>
          
          <el-col :span="8">
            <el-card shadow="hover" class="data-card">
              <template #header>
                <div class="data-header">
                  <span>访问量</span>
                </div>
              </template>
              <div class="data-content">
                <div class="data-value">{{ product.viewCount || 0 }}</div>
                <div class="data-label">次</div>
              </div>
            </el-card>
          </el-col>
        </el-row>
        
        <div class="chart-container" ref="salesChartRef"></div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getProductDetail, getProductSalesData } from '../../api/product'
import * as echarts from 'echarts/core'
import { LineChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

// 注册 ECharts 组件
echarts.use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  LineChart,
  CanvasRenderer
])

const route = useRoute()
const router = useRouter()

// 状态
const product = reactive({})
const salesChartRef = ref(null)
let salesChart = null

// 方法
function formatPrice(price) {
  return parseFloat(price || 0).toFixed(2)
}

function formatDateTime(date) {
  if (!date) return ''
  const d = new Date(date)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

function getStatusType(status) {
  switch (status) {
    case 0: return 'info'     // 下架
    case 1: return 'success'  // 上架
    case 2: return 'warning'  // 审核中
    case 3: return 'danger'   // 审核失败
    default: return 'info'
  }
}

function getStatusText(status) {
  switch (status) {
    case 0: return '下架'
    case 1: return '上架'
    case 2: return '审核中'
    case 3: return '审核失败'
    default: return '未知'
  }
}

// 获取商品详情
async function getProduct() {
  try {
    const res = await getProductDetail(route.params.id)
    Object.assign(product, res.data)
  } catch (error) {
    console.error('获取商品详情失败:', error)
    ElMessage.error('获取商品详情失败')
    router.push('/product/list')
  }
}

// 获取销售数据
async function fetchSalesData() {
  try {
    const res = await getProductSalesData(route.params.id)
    initSalesChart(res.data)
  } catch (error) {
    console.error('获取销售数据失败:', error)
  }
}

// 初始化销售图表
function initSalesChart(data) {
  if (salesChart) {
    salesChart.dispose()
  }
  
  salesChart = echarts.init(salesChartRef.value)
  
  const option = {
    title: {
      text: '近30天销售趋势'
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['销量', '销售额']
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: data.dates
    },
    yAxis: [
      {
        type: 'value',
        name: '销量',
        position: 'left'
      },
      {
        type: 'value',
        name: '销售额',
        position: 'right',
        axisLabel: {
          formatter: '{value} 元'
        }
      }
    ],
    series: [
      {
        name: '销量',
        type: 'line',
        data: data.sales,
        smooth: true
      },
      {
        name: '销售额',
        type: 'line',
        yAxisIndex: 1,
        data: data.amounts,
        smooth: true
      }
    ]
  }
  
  salesChart.setOption(option)
}

// 返回
function goBack() {
  router.push('/product/list')
}

// 编辑
function handleEdit() {
  router.push(`/product/edit/${route.params.id}`)
}

// 处理窗口大小变化
function handleResize() {
  salesChart && salesChart.resize()
}

// 生命周期钩子
onMounted(() => {
  getProduct()
  
  // 初始化图表
  setTimeout(() => {
    fetchSalesData()
  }, 0)
  
  // 监听窗口大小变化
  window.addEventListener('resize', handleResize)
})
</script>

<style lang="scss" scoped>
.product-detail-container {
  .detail-card {
    margin-bottom: 20px;
    
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      
      h2 {
        margin: 0;
        font-size: 20px;
      }
    }
    
    .section-title {
      font-size: 16px;
      font-weight: bold;
      margin: 30px 0 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .image-section {
      .main-image {
        margin-bottom: 20px;
        
        .image-title {
          font-weight: bold;
          margin-bottom: 10px;
        }
      }
      
      .image-list {
        .image-title {
          font-weight: bold;
          margin-bottom: 10px;
        }
        
        .images {
          display: flex;
          flex-wrap: wrap;
        }
      }
    }
    
    .spec-section {
      .spec-title,
      .attr-title {
        font-weight: bold;
        margin-bottom: 10px;
      }
      
      .spec-groups {
        margin-bottom: 20px;
      }
    }
    
    .detail-section {
      .detail-content {
        .detail-text {
          white-space: pre-wrap;
          line-height: 1.6;
          margin-bottom: 20px;
        }
        
        .detail-images {
          .detail-images-title {
            font-weight: bold;
            margin-bottom: 10px;
          }
          
          .detail-image-item {
            margin-bottom: 10px;
            text-align: center;
          }
        }
      }
    }
    
    .sales-section {
      .data-card {
        margin-bottom: 20px;
        
        .data-header {
          font-size: 14px;
        }
        
        .data-content {
          display: flex;
          align-items: baseline;
          
          .data-value {
            font-size: 24px;
            font-weight: bold;
            margin-right: 5px;
          }
          
          .data-label {
            color: #999;
          }
        }
      }
      
      .chart-container {
        height: 400px;
        margin-top: 20px;
      }
    }
  }
}
</style>
